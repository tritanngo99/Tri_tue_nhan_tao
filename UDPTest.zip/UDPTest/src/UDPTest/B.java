package UDPTest;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.HashMap;
import java.util.Map;

public class B {

	public static void main(String[] args) {
		try{
			DatagramSocket soc = new DatagramSocket(5000); // thung thu
			while(true) {
			// Nhan
			DatagramPacket re = new DatagramPacket(new byte[1000],1000); // la thu trang
			soc.receive(re);
			String st = new String(re.getData()).substring(0,re.getLength());
			String p1,p2,p3,p4;
			if(st.length()!=20) st = "Khong hop le";
			else {
			p1 = st.substring(0,12);
			p2 = st.substring(12,15);
			p3 = st.substring(15,17);
			p4= st.substring(17,20);
			if(!p1.equals("ExchangeRate")) st = "Khong hop le";
			if(!(p2.equals("JPY")||p2.equals("VND")||p2.equals("USD"))) st = "Khong hop le";
			if(!(p4.equals("JPY")||p4.equals("VND")||p4.equals("USD"))) st = "Khong hop le";
			if(!p3.equals("to")) st = "Khong hop le";
			if(!st.equals("Khong hop le")) {
				Map<String,Double> mp = new HashMap<>();
				mp.put("USD",new Double(23000));
				mp.put("JPY",new Double(200));
				mp.put("VND",new Double(1));
				st = (mp.get(p2)/mp.get(p4)+"");
			}
			}
			
			DatagramPacket se = new DatagramPacket(st.getBytes(), st.length(),re.getAddress(),re.getPort());
			soc.send(se);
		}
		}
		catch (Exception e) {
			
		}

	}

}
