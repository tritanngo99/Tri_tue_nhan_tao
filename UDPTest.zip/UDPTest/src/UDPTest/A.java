package UDPTest;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class A {

	public static void main(String[] args) {
		
       try {
    	   DatagramSocket soc = new DatagramSocket(); // thung thu
    	   Scanner sc = new Scanner(System.in); // la thu
    	   String st = sc.nextLine(); // nhap noi dung
    	   // Gui
    	   DatagramPacket se = new DatagramPacket(st.getBytes(), st.length(), InetAddress.getByName("localhost"), 5000);
          soc.send(se);
          // Nhan
          DatagramPacket re = new DatagramPacket(new byte[1000], 1000);
          soc.receive(re);
          System.out.println(new String(re.getData()).substring(0,re.getLength()));
       }
       catch (Exception e) {
		
	}
	}

}
